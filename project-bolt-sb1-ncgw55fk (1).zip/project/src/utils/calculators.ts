/**
 * Utility functions for statistical calculations
 */

/**
 * Calculate the covariance between two arrays of numbers
 * cov(X,Y) = Σ[(Xi-X̄)(Yi-Ȳ)] / (n-1)
 */
export const calculateCovariance = (x: number[], y: number[]): number => {
  if (x.length !== y.length || x.length === 0) {
    throw new Error('Arrays must have the same length and cannot be empty');
  }
  
  const n = x.length;
  const xMean = x.reduce((sum, val) => sum + val, 0) / n;
  const yMean = y.reduce((sum, val) => sum + val, 0) / n;
  
  let covariance = 0;
  for (let i = 0; i < n; i++) {
    covariance += (x[i] - xMean) * (y[i] - yMean);
  }
  
  return covariance / (n - 1);
};

/**
 * Calculate the standard deviation of an array of numbers
 * σx = √[Σ(Xi-X̄)² / (n-1)]
 */
export const calculateStandardDeviation = (x: number[]): number => {
  if (x.length === 0) {
    throw new Error('Array cannot be empty');
  }
  
  const n = x.length;
  const mean = x.reduce((sum, val) => sum + val, 0) / n;
  
  let variance = 0;
  for (let i = 0; i < n; i++) {
    variance += Math.pow(x[i] - mean, 2);
  }
  
  variance /= (n - 1);
  return Math.sqrt(variance);
};

/**
 * Calculate Pearson's correlation coefficient between two arrays
 * ρ = cov(X,Y) / (σx·σy)
 */
export const calculatePearsonCorrelation = (x: number[], y: number[]): number => {
  if (x.length !== y.length || x.length === 0) {
    throw new Error('Arrays must have the same length and cannot be empty');
  }
  
  const covariance = calculateCovariance(x, y);
  const stdDevX = calculateStandardDeviation(x);
  const stdDevY = calculateStandardDeviation(y);
  
  if (stdDevX === 0 || stdDevY === 0) {
    return 0; // If either has zero variance, correlation is undefined (return 0)
  }
  
  return covariance / (stdDevX * stdDevY);
};

/**
 * Get the color for a correlation value
 */
export const getCorrelationColor = (value: number): string => {
  // Strong negative (red) to strong positive (blue)
  if (value <= -0.7) return '#d32f2f'; // Strong negative - dark red
  if (value <= -0.3) return '#f44336'; // Moderate negative - red
  if (value < 0) return '#ffcdd2';     // Weak negative - light red
  if (value === 0) return '#e0e0e0';   // No correlation - grey
  if (value < 0.3) return '#bbdefb';   // Weak positive - light blue
  if (value < 0.7) return '#2196f3';   // Moderate positive - blue
  return '#0d47a1';                    // Strong positive - dark blue
};