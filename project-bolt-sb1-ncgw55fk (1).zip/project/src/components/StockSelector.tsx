import React, { useState } from 'react';
import { 
  Box, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  SelectChangeEvent,
  Grid,
  Card,
  Typography,
  useMediaQuery,
  useTheme
} from '@mui/material';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { useStocks, Stock } from '../contexts/StockContext';

const StockSelector: React.FC = () => {
  const { stocks, selectedStock, setSelectedStock } = useStocks();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [stockDropdownOpen, setStockDropdownOpen] = useState(false);

  const handleStockChange = (event: SelectChangeEvent<string>) => {
    const stockId = event.target.value;
    const stock = stocks.find(s => s.id === stockId);
    if (stock) {
      setSelectedStock(stock);
    }
  };

  const handleStockCardClick = (stock: Stock) => {
    setSelectedStock(stock);
  };

  return (
    <Box sx={{ mt: 2 }}>
      {isMobile ? (
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel id="stock-select-label">Select Stock</InputLabel>
          <Select
            labelId="stock-select-label"
            id="stock-select"
            value={selectedStock?.id || ''}
            label="Select Stock"
            onChange={handleStockChange}
            open={stockDropdownOpen}
            onOpen={() => setStockDropdownOpen(true)}
            onClose={() => setStockDropdownOpen(false)}
          >
            {stocks.map((stock) => (
              <MenuItem key={stock.id} value={stock.id}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                  <Typography>{stock.name} ({stock.symbol})</Typography>
                  <Typography 
                    sx={{ 
                      ml: 2, 
                      color: stock.change >= 0 ? 'success.main' : 'error.main',
                      display: 'flex',
                      alignItems: 'center' 
                    }}
                  >
                    ${stock.currentPrice.toFixed(2)}
                    <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', ml: 0.5 }}>
                      {stock.change >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                    </Box>
                  </Typography>
                </Box>
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      ) : (
        <Grid container spacing={2}>
          {stocks.map((stock) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={stock.id}>
              <Card 
                sx={{ 
                  p: 2,
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  transform: selectedStock?.id === stock.id ? 'scale(1.02)' : 'scale(1)',
                  border: selectedStock?.id === stock.id ? `2px solid ${theme.palette.primary.main}` : 'none',
                  '&:hover': {
                    boxShadow: '0 8px 16px rgba(0,0,0,0.1)',
                    transform: 'translateY(-4px)'
                  }
                }}
                onClick={() => handleStockCardClick(stock)}
              >
                <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                  {stock.symbol}
                </Typography>
                <Typography variant="body2" color="textSecondary" sx={{ mb: 1 }}>
                  {stock.name}
                </Typography>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    color: stock.change >= 0 ? 'success.main' : 'error.main',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  ${stock.currentPrice.toFixed(2)}
                  <Box 
                    sx={{ 
                      display: 'flex', 
                      alignItems: 'center',
                      backgroundColor: stock.change >= 0 ? 'rgba(76, 175, 80, 0.1)' : 'rgba(244, 67, 54, 0.1)',
                      borderRadius: 1,
                      px: 1,
                      py: 0.5
                    }}
                  >
                    {stock.change >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                    <Typography variant="body2" sx={{ ml: 0.5 }}>
                      {stock.percentChange.toFixed(2)}%
                    </Typography>
                  </Box>
                </Typography>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default StockSelector;