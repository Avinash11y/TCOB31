import React, { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { LineChart, Menu as MenuIcon, TrendingUp, Grid, SunMoon } from 'lucide-react';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';

interface LayoutProps {
  children: ReactNode;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, darkMode, toggleDarkMode }) => {
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const routes = [
    { name: 'Price Analysis', path: '/stocks', icon: <TrendingUp size={22} /> },
    { name: 'Market Correlation', path: '/heatmap', icon: <Grid size={22} /> },
  ];

  const toggleDrawer = () => {
    setDrawerOpen(!drawerOpen);
  };

  const DrawerContent = (
    <Box sx={{ width: 280 }} role="presentation">
      <List>
        <ListItem disablePadding sx={{ display: 'flex', justifyContent: 'center' }}>
          <Box sx={{ py: 3, display: 'flex', alignItems: 'center' }}>
            <LineChart size={28} color={theme.palette.primary.main} />
            <Typography variant="h5" sx={{ ml: 1.5, fontWeight: 600, color: theme.palette.primary.main }}>
              MarketPulse
            </Typography>
          </Box>
        </ListItem>
        {routes.map((route) => (
          <ListItem key={route.path} disablePadding>
            <ListItemButton
              component={Link}
              to={route.path}
              selected={location.pathname === route.path}
              onClick={() => isMobile && toggleDrawer()}
              sx={{
                mx: 2,
                borderRadius: 2,
                '&.Mui-selected': {
                  backgroundColor: 'primary.main',
                  color: 'white',
                  '&:hover': {
                    backgroundColor: 'primary.dark',
                  },
                  '& .MuiListItemIcon-root': {
                    color: 'white',
                  },
                },
              }}
            >
              <ListItemIcon sx={{ minWidth: 40 }}>{route.icon}</ListItemIcon>
              <ListItemText primary={route.name} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <AppBar 
        position="fixed" 
        sx={{ 
          zIndex: theme.zIndex.drawer + 1,
          backdropFilter: 'blur(8px)',
          backgroundColor: 'rgba(44, 62, 80, 0.95)',
        }}
      >
        <Toolbar>
          {isMobile && (
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              onClick={toggleDrawer}
              sx={{ mr: 2 }}
            >
              <MenuIcon />
            </IconButton>
          )}
          <Typography variant="h6" component="div" sx={{ display: 'flex', alignItems: 'center' }}>
            <LineChart size={28} />
            <Box sx={{ ml: 1.5, fontWeight: 600 }}>MarketPulse</Box>
          </Typography>
          <Box sx={{ flexGrow: 1 }} />
          {!isMobile && routes.map((route) => (
            <Button
              key={route.path}
              component={Link}
              to={route.path}
              color="inherit"
              startIcon={route.icon}
              sx={{ 
                mx: 1,
                py: 1,
                px: 2,
                borderRadius: 2,
                backgroundColor: location.pathname === route.path ? 'rgba(255, 255, 255, 0.1)' : 'transparent',
                '&:hover': {
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                },
              }}
            >
              {route.name}
            </Button>
          ))}
          <IconButton 
            color="inherit" 
            onClick={toggleDarkMode}
            sx={{ 
              ml: 2,
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
              },
            }}
          >
            <SunMoon />
          </IconButton>
        </Toolbar>
      </AppBar>
      {isMobile ? (
        <Drawer
          anchor="left"
          open={drawerOpen}
          onClose={toggleDrawer}
          PaperProps={{
            sx: {
              backgroundColor: theme.palette.background.default,
            },
          }}
        >
          {DrawerContent}
        </Drawer>
      ) : (
        <Drawer
          variant="permanent"
          sx={{
            width: 280,
            flexShrink: 0,
            '& .MuiDrawer-paper': {
              width: 280,
              boxSizing: 'border-box',
              mt: '64px',
              backgroundColor: theme.palette.background.default,
            },
          }}
        >
          {DrawerContent}
        </Drawer>
      )}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          ml: isMobile ? 0 : '280px',
          mt: '64px',
          backgroundColor: darkMode ? '#1a1a1a' : theme.palette.background.default,
          color: darkMode ? '#fff' : theme.palette.text.primary,
          transition: 'background-color 0.3s, color 0.3s',
        }}
      >
        {children}
      </Box>
    </Box>
  );
};

export default Layout;