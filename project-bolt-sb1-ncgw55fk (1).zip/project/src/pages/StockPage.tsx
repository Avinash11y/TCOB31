import { useState, useEffect } from 'react';
import { Box, Typography, Card, Grid, Paper, ToggleButtonGroup, ToggleButton, CircularProgress } from '@mui/material';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ReferenceLine, Legend, Area, AreaChart 
} from 'recharts';
import { useStocks } from '../contexts/StockContext';
import { useTimeInterval, TimeInterval } from '../contexts/TimeIntervalContext';
import { fetchStockPriceHistory } from '../services/api';
import StockSelector from '../components/StockSelector';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface DataPoint {
  timestamp: string;
  price: number;
}

const StockPage = () => {
  const { selectedStock, loading: stocksLoading } = useStocks();
  const { timeInterval, setTimeInterval } = useTimeInterval();
  const [priceData, setPriceData] = useState<DataPoint[]>([]);
  const [average, setAverage] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (!selectedStock) return;
    
    const fetchPriceData = async () => {
      setLoading(true);
      try {
        const data = await fetchStockPriceHistory(selectedStock.symbol, timeInterval);
        setPriceData(data);
        
        // Calculate average price
        const avg = data.reduce((sum, point) => sum + point.price, 0) / data.length;
        setAverage(parseFloat(avg.toFixed(2)));
      } catch (error) {
        console.error('Error fetching price data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchPriceData();
  }, [selectedStock, timeInterval]);

  const handleTimeIntervalChange = (_: React.MouseEvent<HTMLElement>, newInterval: TimeInterval) => {
    if (newInterval !== null) {
      setTimeInterval(newInterval);
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    
    switch (timeInterval) {
      case '1d':
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      case '1w':
        return `${date.toLocaleDateString([], { weekday: 'short' })} ${date.toLocaleTimeString([], { hour: '2-digit' })}`;
      case '1m':
      case '3m':
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
      case '6m':
      case '1y':
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
      default:
        return date.toLocaleString();
    }
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <Paper elevation={3} sx={{ p: 2, backgroundColor: 'rgba(255, 255, 255, 0.95)' }}>
          <Typography variant="subtitle2" color="textSecondary">
            {formatTimestamp(data.timestamp)}
          </Typography>
          <Typography variant="h6" sx={{ color: 'primary.main', fontWeight: 'bold', my: 1 }}>
            ${data.price.toFixed(2)}
          </Typography>
        </Paper>
      );
    }
    return null;
  };

  if (stocksLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '70vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
        Stock Price Analysis
      </Typography>
      
      <StockSelector />
      
      <Card sx={{ mt: 3, p: 3, boxShadow: '0 4px 20px rgba(0, 0, 0, 0.05)' }}>
        {selectedStock && (
          <Grid container spacing={3}>
            <Grid item xs={12} md={9}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Typography variant="h5" component="h2" sx={{ fontWeight: 'bold' }}>
                  {selectedStock.name} ({selectedStock.symbol})
                </Typography>
                <Typography 
                  variant="h6" 
                  component="span" 
                  sx={{ 
                    ml: 2,
                    color: selectedStock.change >= 0 ? 'success.main' : 'error.main',
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  ${selectedStock.currentPrice.toFixed(2)}
                  <Box component="span" sx={{ display: 'flex', alignItems: 'center', ml: 1 }}>
                    {selectedStock.change >= 0 ? (
                      <TrendingUp size={16} />
                    ) : (
                      <TrendingDown size={16} />
                    )}
                    {selectedStock.change.toFixed(2)} ({selectedStock.percentChange.toFixed(2)}%)
                  </Box>
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} md={3}>
              <Box sx={{ display: 'flex', justifyContent: { xs: 'flex-start', md: 'flex-end' } }}>
                <ToggleButtonGroup
                  value={timeInterval}
                  exclusive
                  onChange={handleTimeIntervalChange}
                  size="small"
                  aria-label="time interval"
                >
                  <ToggleButton value="1d" aria-label="1 day">1D</ToggleButton>
                  <ToggleButton value="1w" aria-label="1 week">1W</ToggleButton>
                  <ToggleButton value="1m" aria-label="1 month">1M</ToggleButton>
                  <ToggleButton value="3m" aria-label="3 months">3M</ToggleButton>
                  <ToggleButton value="6m" aria-label="6 months">6M</ToggleButton>
                  <ToggleButton value="1y" aria-label="1 year">1Y</ToggleButton>
                </ToggleButtonGroup>
              </Box>
            </Grid>
            
            <Grid item xs={12}>
              {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
                  <CircularProgress />
                </Box>
              ) : (
                <Box sx={{ height: 400, width: '100%', mt: 2 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={priceData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#1976d2" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#1976d2" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="timestamp" 
                        tickFormatter={formatTimestamp}
                        minTickGap={30}
                      />
                      <YAxis 
                        domain={['auto', 'auto']}
                        tickFormatter={(value) => `$${value.toFixed(2)}`} 
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="price" 
                        stroke="#1976d2" 
                        fillOpacity={1} 
                        fill="url(#colorPrice)" 
                        name="Price" 
                        activeDot={{ r: 8 }}
                      />
                      {average && (
                        <ReferenceLine 
                          y={average} 
                          label="Average" 
                          stroke="#ff9800" 
                          strokeDasharray="3 3" 
                        />
                      )}
                    </AreaChart>
                  </ResponsiveContainer>
                </Box>
              )}
            </Grid>
            
            {!loading && average && (
              <Grid item xs={12}>
                <Typography variant="body1" sx={{ mt: 2, textAlign: 'center', color: 'text.secondary' }}>
                  Average price over {timeInterval}: <strong>${average}</strong>
                </Typography>
              </Grid>
            )}
          </Grid>
        )}
        
        {!selectedStock && (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="body1">
              Please select a stock to view its price chart.
            </Typography>
          </Box>
        )}
      </Card>
    </Box>
  );
};

export default StockPage;