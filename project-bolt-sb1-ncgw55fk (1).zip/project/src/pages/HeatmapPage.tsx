import { useState, useEffect } from 'react';
import { Box, Typography, Card, Grid, Paper, ToggleButtonGroup, ToggleButton, CircularProgress } from '@mui/material';
import { useTimeInterval, TimeInterval } from '../contexts/TimeIntervalContext';
import { fetchCorrelationData } from '../services/api';
import { getCorrelationColor } from '../utils/calculators';

interface CorrelationData {
  symbols: string[];
  correlationMatrix: number[][];
}

const HeatmapPage = () => {
  const { timeInterval, setTimeInterval, getMinutes } = useTimeInterval();
  const [correlationData, setCorrelationData] = useState<CorrelationData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [hoveredCell, setHoveredCell] = useState<{ i: number, j: number } | null>(null);
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const [stats, setStats] = useState<{ mean: number, stdDev: number } | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const minutes = getMinutes();
        const data = await fetchCorrelationData(minutes);
        setCorrelationData(data);
        
        // Calculate mean and standard deviation for the selected symbol
        if (selectedSymbol && data.symbols.includes(selectedSymbol)) {
          const symbolIndex = data.symbols.indexOf(selectedSymbol);
          const correlations = data.correlationMatrix[symbolIndex].filter((_, i) => i !== symbolIndex);
          
          const sum = correlations.reduce((acc, val) => acc + val, 0);
          const mean = sum / correlations.length;
          
          const squaredDiffs = correlations.map(val => Math.pow(val - mean, 2));
          const avgSquaredDiff = squaredDiffs.reduce((acc, val) => acc + val, 0) / correlations.length;
          const stdDev = Math.sqrt(avgSquaredDiff);
          
          setStats({ mean: parseFloat(mean.toFixed(4)), stdDev: parseFloat(stdDev.toFixed(4)) });
        } else {
          setStats(null);
        }
      } catch (error) {
        console.error('Error fetching correlation data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [timeInterval, getMinutes, selectedSymbol]);

  const handleTimeIntervalChange = (_: React.MouseEvent<HTMLElement>, newInterval: TimeInterval) => {
    if (newInterval !== null) {
      setTimeInterval(newInterval);
    }
  };

  const handleCellHover = (i: number, j: number) => {
    setHoveredCell({ i, j });
  };

  const handleCellLeave = () => {
    setHoveredCell(null);
  };

  const handleSymbolClick = (symbol: string) => {
    setSelectedSymbol(symbol === selectedSymbol ? null : symbol);
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
        Stock Correlation Heatmap
      </Typography>
      
      <Card sx={{ mt: 3, p: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
              <Typography variant="h6">
                Correlation Matrix - Past{' '}
                {timeInterval === '1d' ? '24 hours' : 
                 timeInterval === '1w' ? 'week' : 
                 timeInterval === '1m' ? 'month' :
                 timeInterval === '3m' ? '3 months' :
                 timeInterval === '6m' ? '6 months' : 'year'}
              </Typography>
              
              <ToggleButtonGroup
                value={timeInterval}
                exclusive
                onChange={handleTimeIntervalChange}
                size="small"
                aria-label="time interval"
              >
                <ToggleButton value="1d" aria-label="1 day">1D</ToggleButton>
                <ToggleButton value="1w" aria-label="1 week">1W</ToggleButton>
                <ToggleButton value="1m" aria-label="1 month">1M</ToggleButton>
                <ToggleButton value="3m" aria-label="3 months">3M</ToggleButton>
                <ToggleButton value="6m" aria-label="6 months">6M</ToggleButton>
                <ToggleButton value="1y" aria-label="1 year">1Y</ToggleButton>
              </ToggleButtonGroup>
            </Box>
          </Grid>

          <Grid item xs={12}>
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 10 }}>
                <CircularProgress />
              </Box>
            ) : correlationData ? (
              <Box>
                <Box sx={{ overflow: 'auto', maxWidth: '100%' }}>
                  <Box sx={{ minWidth: 600, display: 'inline-block' }}>
                    <Box sx={{ display: 'flex' }}>
                      {/* Empty corner cell */}
                      <Box sx={{ width: 60, height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Typography variant="body2" sx={{ fontWeight: 'bold', transform: 'rotate(-45deg)' }}>
                          Symbol
                        </Typography>
                      </Box>
                      
                      {/* Column headers */}
                      {correlationData.symbols.map((symbol, index) => (
                        <Box 
                          key={`col-${symbol}`} 
                          sx={{ 
                            width: 60, 
                            height: 60, 
                            display: 'flex', 
                            alignItems: 'center', 
                            justifyContent: 'center',
                            backgroundColor: selectedSymbol === symbol ? 'rgba(25, 118, 210, 0.1)' : 'transparent',
                            cursor: 'pointer'
                          }}
                          onClick={() => handleSymbolClick(symbol)}
                        >
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              fontWeight: 'bold', 
                              transform: 'rotate(-45deg)',
                              color: selectedSymbol === symbol ? 'primary.main' : 'inherit'
                            }}
                          >
                            {symbol}
                          </Typography>
                        </Box>
                      ))}
                    </Box>
                    
                    {/* Matrix rows */}
                    {correlationData.symbols.map((rowSymbol, i) => (
                      <Box key={`row-${rowSymbol}`} sx={{ display: 'flex' }}>
                        {/* Row header */}
                        <Box 
                          sx={{ 
                            width: 60, 
                            height: 60, 
                            display: 'flex', 
                            alignItems: 'center', 
                            justifyContent: 'center',
                            backgroundColor: selectedSymbol === rowSymbol ? 'rgba(25, 118, 210, 0.1)' : 'transparent',
                            cursor: 'pointer'
                          }}
                          onClick={() => handleSymbolClick(rowSymbol)}
                        >
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              fontWeight: 'bold',
                              color: selectedSymbol === rowSymbol ? 'primary.main' : 'inherit'
                            }}
                          >
                            {rowSymbol}
                          </Typography>
                        </Box>
                        
                        {/* Correlation cells */}
                        {correlationData.correlationMatrix[i].map((value, j) => {
                          const isHighlighted = 
                            selectedSymbol !== null && 
                            (rowSymbol === selectedSymbol || correlationData.symbols[j] === selectedSymbol);
                          
                          return (
                            <Box 
                              key={`cell-${i}-${j}`}
                              sx={{ 
                                width: 60, 
                                height: 60, 
                                display: 'flex', 
                                alignItems: 'center', 
                                justifyContent: 'center',
                                backgroundColor: getCorrelationColor(value),
                                opacity: isHighlighted ? 1 : selectedSymbol !== null ? 0.5 : 1,
                                border: hoveredCell?.i === i && hoveredCell?.j === j ? '2px solid black' : '1px solid rgba(0,0,0,0.1)',
                                transition: 'all 0.2s ease',
                                cursor: 'pointer'
                              }}
                              onMouseEnter={() => handleCellHover(i, j)}
                              onMouseLeave={handleCellLeave}
                            >
                              <Typography 
                                variant="body2" 
                                sx={{ 
                                  fontWeight: 'bold',
                                  color: Math.abs(value) > 0.5 ? 'white' : 'black'
                                }}
                              >
                                {value.toFixed(2)}
                              </Typography>
                            </Box>
                          );
                        })}
                      </Box>
                    ))}
                  </Box>
                </Box>
                
                {/* Legend */}
                <Box sx={{ mt: 4, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <Typography variant="body1" gutterBottom>
                    Correlation Strength
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', maxWidth: 500 }}>
                    <Box sx={{ width: '100%', height: 20, background: 'linear-gradient(to right, #d32f2f, #f44336, #ffcdd2, #e0e0e0, #bbdefb, #2196f3, #0d47a1)' }}></Box>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', maxWidth: 500, mt: 1 }}>
                    <Typography variant="caption">-1.0</Typography>
                    <Typography variant="caption">-0.5</Typography>
                    <Typography variant="caption">0</Typography>
                    <Typography variant="caption">0.5</Typography>
                    <Typography variant="caption">1.0</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%', maxWidth: 500 }}>
                    <Typography variant="caption">Strong Negative</Typography>
                    <Typography variant="caption" sx={{ textAlign: 'center' }}>No Correlation</Typography>
                    <Typography variant="caption">Strong Positive</Typography>
                  </Box>
                </Box>
                
                {/* Stats for selected stock */}
                {selectedSymbol && stats && (
                  <Paper elevation={2} sx={{ mt: 4, p: 2 }}>
                    <Typography variant="h6" gutterBottom>
                      Statistics for {selectedSymbol}
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={6}>
                        <Typography variant="body1">
                          Mean Correlation: <strong>{stats.mean}</strong>
                        </Typography>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <Typography variant="body1">
                          Standard Deviation: <strong>{stats.stdDev}</strong>
                        </Typography>
                      </Grid>
                    </Grid>
                  </Paper>
                )}
                
                {hoveredCell && (
                  <Box sx={{ mt: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      Correlation between {correlationData.symbols[hoveredCell.i]} and {correlationData.symbols[hoveredCell.j]}:{' '}
                      <strong>{correlationData.correlationMatrix[hoveredCell.i][hoveredCell.j].toFixed(4)}</strong>
                    </Typography>
                  </Box>
                )}
              </Box>
            ) : (
              <Typography variant="body1" sx={{ textAlign: 'center', py: 4 }}>
                No correlation data available.
              </Typography>
            )}
          </Grid>
        </Grid>
      </Card>
    </Box>
  );
};

export default HeatmapPage;