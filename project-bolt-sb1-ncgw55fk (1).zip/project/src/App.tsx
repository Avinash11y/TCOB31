import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Layout from './components/Layout';
import StockPage from './pages/StockPage';
import HeatmapPage from './pages/HeatmapPage';
import { StockProvider } from './contexts/StockContext';
import { TimeIntervalProvider } from './contexts/TimeIntervalContext';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  return (
    <StockProvider>
      <TimeIntervalProvider>
        <Layout darkMode={darkMode} toggleDarkMode={toggleDarkMode}>
          <Container maxWidth={false} sx={{ mt: 2, mb: 4 }}>
            <Box sx={{ py: 2 }}>
              <Routes>
                <Route path="/" element={<StockPage />} />
                <Route path="/stocks" element={<StockPage />} />
                <Route path="/heatmap" element={<HeatmapPage />} />
              </Routes>
            </Box>
          </Container>
        </Layout>
      </TimeIntervalProvider>
    </StockProvider>
  );
}

export default App;