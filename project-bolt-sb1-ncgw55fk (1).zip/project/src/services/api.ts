import axios from 'axios';
import { Stock } from '../contexts/StockContext';
import { TimeInterval } from '../contexts/TimeIntervalContext';

// Simulated API endpoint (replace with actual API endpoint when available)
const API_BASE_URL = 'http://localhost:3000/api';

// Mock data for development (remove when actual API is available)
const mockStocks: Stock[] = [
  {
    id: '1',
    symbol: 'AAPL',
    name: 'Apple Inc.',
    currentPrice: 178.72,
    previousClose: 177.97,
    change: 0.75,
    percentChange: 0.42
  },
  {
    id: '2',
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    currentPrice: 410.34,
    previousClose: 415.50,
    change: -5.16,
    percentChange: -1.24
  },
  {
    id: '3',
    symbol: 'GOOGL',
    name: 'Alphabet Inc.',
    currentPrice: 161.10,
    previousClose: 160.79,
    change: 0.31,
    percentChange: 0.19
  },
  {
    id: '4',
    symbol: 'AMZN',
    name: 'Amazon.com Inc.',
    currentPrice: 178.15,
    previousClose: 180.75,
    change: -2.60,
    percentChange: -1.44
  },
  {
    id: '5',
    symbol: 'META',
    name: 'Meta Platforms, Inc.',
    currentPrice: 470.00,
    previousClose: 465.50,
    change: 4.50,
    percentChange: 0.97
  },
  {
    id: '6',
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    currentPrice: 175.35,
    previousClose: 177.80,
    change: -2.45,
    percentChange: -1.38
  },
  {
    id: '7',
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    currentPrice: 950.02,
    previousClose: 941.90,
    change: 8.12,
    percentChange: 0.86
  }
];

// Mock time series data
const generateMockTimeSeriesData = (stockSymbol: string, interval: TimeInterval) => {
  const now = new Date();
  const dataPoints = [];
  let intervalMinutes: number;
  let totalPoints: number;
  
  // Determine interval settings
  switch(interval) {
    case '1d':
      intervalMinutes = 5;
      totalPoints = 24 * 12; // 5-minute intervals for 1 day
      break;
    case '1w':
      intervalMinutes = 60;
      totalPoints = 24 * 7; // Hourly for 1 week
      break;
    case '1m':
      intervalMinutes = 24 * 60;
      totalPoints = 30; // Daily for 1 month
      break;
    case '3m':
      intervalMinutes = 24 * 60;
      totalPoints = 90; // Daily for 3 months
      break;
    case '6m':
      intervalMinutes = 24 * 60;
      totalPoints = 180; // Daily for 6 months
      break;
    case '1y':
      intervalMinutes = 24 * 60 * 7;
      totalPoints = 52; // Weekly for 1 year
      break;
    default:
      intervalMinutes = 5;
      totalPoints = 24 * 12;
  }

  // Find the base stock in our mock data
  const stock = mockStocks.find(s => s.symbol === stockSymbol);
  const basePrice = stock ? stock.currentPrice : 100;
  
  // Generate data points
  for (let i = totalPoints - 1; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * intervalMinutes * 60 * 1000);
    
    // Add some randomness to make the chart look realistic
    // More volatility for shorter timeframes
    const volatility = interval === '1d' ? 0.02 : interval === '1w' ? 0.05 : 0.1;
    const randomFactor = 1 + (Math.random() - 0.5) * volatility;
    
    // Create a general trend (upward or downward)
    const trendFactor = 1 + (0.0002 * i) * (Math.random() > 0.5 ? 1 : -1);
    
    const price = basePrice * randomFactor * trendFactor;
    
    dataPoints.push({
      timestamp: timestamp.toISOString(),
      price: parseFloat(price.toFixed(2))
    });
  }
  
  return dataPoints;
};

// Generate mock correlation data
const generateMockCorrelationData = (minutes: number) => {
  const symbols = mockStocks.map(stock => stock.symbol);
  const correlationMatrix: number[][] = [];
  
  for (let i = 0; i < symbols.length; i++) {
    correlationMatrix[i] = [];
    for (let j = 0; j < symbols.length; j++) {
      if (i === j) {
        correlationMatrix[i][j] = 1; // Self-correlation is always 1
      } else if (correlationMatrix[j] && correlationMatrix[j][i] !== undefined) {
        correlationMatrix[i][j] = correlationMatrix[j][i]; // Correlation matrix is symmetric
      } else {
        // Generate random correlation between -1 and 1
        // Higher chance of positive correlation
        correlationMatrix[i][j] = (Math.random() * 1.7) - 0.7;
        
        // Clamp values to [-1, 1]
        if (correlationMatrix[i][j] > 1) correlationMatrix[i][j] = 1;
        if (correlationMatrix[i][j] < -1) correlationMatrix[i][j] = -1;
        
        // Round to 2 decimal places
        correlationMatrix[i][j] = Math.round(correlationMatrix[i][j] * 100) / 100;
      }
    }
  }
  
  return { symbols, correlationMatrix };
};

// API functions
export const fetchStocks = async (): Promise<Stock[]> => {
  try {
    // In a real app, this would be:
    // const response = await axios.get(`${API_BASE_URL}/stocks`);
    // return response.data;
    
    // Using mock data for development
    return new Promise(resolve => {
      setTimeout(() => resolve(mockStocks), 500);
    });
  } catch (error) {
    console.error('Error fetching stocks:', error);
    throw error;
  }
};

export const fetchStockPriceHistory = async (symbol: string, interval: TimeInterval) => {
  try {
    // In a real app, this would be:
    // const response = await axios.get(`${API_BASE_URL}/stocks/${symbol}/history`, {
    //   params: { interval }
    // });
    // return response.data;
    
    // Using mock data for development
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(generateMockTimeSeriesData(symbol, interval));
      }, 500);
    });
  } catch (error) {
    console.error(`Error fetching price history for ${symbol}:`, error);
    throw error;
  }
};

export const fetchCorrelationData = async (minutes: number) => {
  try {
    // In a real app, this would be:
    // const response = await axios.get(`${API_BASE_URL}/correlation`, {
    //   params: { minutes }
    // });
    // return response.data;
    
    // Using mock data for development
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(generateMockCorrelationData(minutes));
      }, 800);
    });
  } catch (error) {
    console.error('Error fetching correlation data:', error);
    throw error;
  }
};