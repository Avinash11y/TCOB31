import { createContext, useState, useContext, ReactNode } from 'react';

export type TimeInterval = '1d' | '1w' | '1m' | '3m' | '6m' | '1y';

interface TimeIntervalContextType {
  timeInterval: TimeInterval;
  setTimeInterval: (interval: TimeInterval) => void;
  getMinutes: () => number;
}

const TimeIntervalContext = createContext<TimeIntervalContextType>({
  timeInterval: '1d',
  setTimeInterval: () => {},
  getMinutes: () => 0,
});

export const useTimeInterval = () => useContext(TimeIntervalContext);

interface TimeIntervalProviderProps {
  children: ReactNode;
}

export const TimeIntervalProvider = ({ children }: TimeIntervalProviderProps) => {
  const [timeInterval, setTimeInterval] = useState<TimeInterval>('1d');

  const getMinutes = (): number => {
    switch (timeInterval) {
      case '1d': return 24 * 60;
      case '1w': return 7 * 24 * 60;
      case '1m': return 30 * 24 * 60;
      case '3m': return 90 * 24 * 60;
      case '6m': return 180 * 24 * 60;
      case '1y': return 365 * 24 * 60;
      default: return 24 * 60;
    }
  };

  return (
    <TimeIntervalContext.Provider
      value={{
        timeInterval,
        setTimeInterval,
        getMinutes,
      }}
    >
      {children}
    </TimeIntervalContext.Provider>
  );
};