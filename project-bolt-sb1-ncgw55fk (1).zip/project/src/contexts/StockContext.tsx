import { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { fetchStocks } from '../services/api';

export interface Stock {
  id: string;
  symbol: string;
  name: string;
  currentPrice: number;
  previousClose: number;
  change: number;
  percentChange: number;
}

interface StockContextType {
  stocks: Stock[];
  selectedStock: Stock | null;
  loading: boolean;
  error: string | null;
  setSelectedStock: (stock: Stock) => void;
  refreshStocks: () => Promise<void>;
}

const StockContext = createContext<StockContextType>({
  stocks: [],
  selectedStock: null,
  loading: false,
  error: null,
  setSelectedStock: () => {},
  refreshStocks: async () => {},
});

export const useStocks = () => useContext(StockContext);

interface StockProviderProps {
  children: ReactNode;
}

export const StockProvider = ({ children }: StockProviderProps) => {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const refreshStocks = async () => {
    setLoading(true);
    try {
      const data = await fetchStocks();
      setStocks(data);
      if (data.length > 0 && !selectedStock) {
        setSelectedStock(data[0]);
      }
      setError(null);
    } catch (err) {
      setError('Failed to fetch stocks. Please try again later.');
      console.error('Error fetching stocks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshStocks();
    
    // Set up polling for real-time updates (every 30 seconds)
    const intervalId = setInterval(refreshStocks, 30000);
    
    return () => clearInterval(intervalId);
  }, []);

  return (
    <StockContext.Provider
      value={{
        stocks,
        selectedStock,
        loading,
        error,
        setSelectedStock,
        refreshStocks,
      }}
    >
      {children}
    </StockContext.Provider>
  );
};